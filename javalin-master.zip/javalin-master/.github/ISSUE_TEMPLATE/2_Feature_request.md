---
name: "\U0001F6A9 Feature request"
about: Use this template to suggest/request a feature

---

**Describe the feature**
A description of the feature

**Additional context**
Add any other context about the feature request here
