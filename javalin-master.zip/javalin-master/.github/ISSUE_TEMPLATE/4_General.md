---
name: "\U0001F4DD General issue"
about: Use this template if the other templates don't fit

---

**Describe your issue**