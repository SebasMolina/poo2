---
name: "⚠️ Bug report"
about: Use this template to create a bug report

---

**Actual behavior (the bug)**
A description of what happened

**Expected behavior**
A description of what you expected to happen

**To Reproduce**
Steps to reproduce the behavior

**Additional context**
Add any other context about the bug here
