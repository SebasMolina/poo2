document.write("<h2>JavaScript works</h2>");
