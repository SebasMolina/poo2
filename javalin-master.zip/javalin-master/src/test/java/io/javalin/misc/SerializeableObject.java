package io.javalin.misc;

import java.io.Serializable;

public class SerializeableObject implements Serializable {
    public String value1 = "First value";
    public String value2 = "Second value";
}
