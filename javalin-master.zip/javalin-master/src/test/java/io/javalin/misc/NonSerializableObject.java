package io.javalin.misc;

public class NonSerializableObject {
    private String value1 = "First value";
    private String value2 = "Second value";
}
