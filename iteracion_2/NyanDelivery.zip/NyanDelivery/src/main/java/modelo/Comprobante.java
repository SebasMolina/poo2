
package modelo;


public class Comprobante {
    private int id;
    private String cabecera;
    private Usuario cliente;
    private DetalleComprobante detalle;

/** Constructor por defecto;
 * 
 */
    public Comprobante() {
    }
    
    
    
}
